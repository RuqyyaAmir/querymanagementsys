# Query-Mgt-System
We are developing the plugin for Query Management System in Wordpress
