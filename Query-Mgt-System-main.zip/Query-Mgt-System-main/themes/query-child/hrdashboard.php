<?php
/*
  Template Name: hrdashboard
*/
?>

<?php
$testing = do_shortcode('[hrdashboard_shortcode]');
echo $testing;
