<?php
/*
  Template Name: report
*/
?>

<?php
$testing = do_shortcode('[reportsystem_shortcode]');
echo $testing;
