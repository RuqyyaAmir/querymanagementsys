<?php
/*
  Template Name: query
*/
?>

<?php
$testing = do_shortcode('[my_login_shortcode]');
echo $testing;
