<?php
/*
  Template Name: registration
*/
?>

<?php
$testing = do_shortcode('[my_registeration_shortcode]');
echo $testing;
