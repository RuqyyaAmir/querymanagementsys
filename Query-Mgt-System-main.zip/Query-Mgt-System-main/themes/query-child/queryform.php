<?php
/*
  Template Name: queryform
*/
?>

<?php
$testing = do_shortcode('[my_queryform_shortcode]');
echo $testing;
