<?php
/*
  Template Name: replyform
*/
?>

<?php
$testing = do_shortcode('[replyform_shortcode]');
echo $testing;
