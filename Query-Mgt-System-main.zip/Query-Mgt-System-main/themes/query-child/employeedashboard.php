<?php
/*
  Template Name: employeedashboard
*/
?>

<?php
$testing = do_shortcode('[employee_shortcode]');
echo $testing;
